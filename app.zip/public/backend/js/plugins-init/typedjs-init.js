(function($) {
    "use strict"


    var typed = new Typed('.element', {
        strings: ["This is First sentence", "This is Second sentence."],
        typeSpeed: 50
      });




})(jQuery);