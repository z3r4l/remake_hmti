$("#bootgrid-basic").bootgrid();

$("#bootgrid-data").bootgrid({
    icon: "icon glyphicon",

iconColumns: "glyphicon-list",

iconDown: "glyphicon-triangle-bottom",

iconRefresh: "glyphicon-repeat",

iconSearch: "glyphicon-search"
});